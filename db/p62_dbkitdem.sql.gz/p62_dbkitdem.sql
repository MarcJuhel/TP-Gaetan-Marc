-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mer 03 Août 2016 à 20:44
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `p62_dbkitdem`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL COMMENT 'Id (clef principale) de l''article',
  `name` varchar(256) NOT NULL COMMENT 'Nom de l''article ',
  `category_id` int(11) DEFAULT NULL COMMENT AS `Catégorie à laquelle appartient l'article`,
  `description` varchar(1024) NOT NULL COMMENT 'Description de l''article',
  `picture` varchar(128) NOT NULL COMMENT 'Photo de l''article',
  `price` decimal(8,2) DEFAULT NULL COMMENT AS `Prix de l'article`,
  `is_online` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Indique si l''article est affiché ou pas'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Table des articles (forfaits, livres, metériel, etc...) du site';

--
-- Contenu de la table `article`
--

INSERT INTO `article` (`id`, `name`, `category_id`, `description`, `picture`, `price`, `is_online`) VALUES
(1, 'Céline au Centre Bell', 1, 'Bla bla bla en HTML', 'photo_article.jpg', '159.99', 1),
(2, 'Grand prix cycliste de Montréal', 2, 'Bla bla bla en HTML', 'photo_article.jpg', '98.90', 1),
(3, 'Lady Gaga au centre Bell', 1, 'Bla bla bla en HTML', 'photo_article.jpg', '134.00', 1),
(4, 'Formule 1 au Parc Jean Drapeau', 2, 'Bla bla bla en HTML', 'photo_article.jpg', '225.00', 1),
(5, 'Concert des Fifty Six', 1, 'Bla bla bla en HTML', 'photo_article.jpg', '112.00', 1),
(52, 'Portes ouvertes insectarium de Montréal', 3, 'L\'insectarium de Montréal est heureux d\'ouvrir sa <em>fabuleuse collection</em> de papillons ...', '', '0.00', 1);

-- --------------------------------------------------------

--
-- Structure de la table `article_category`
--

CREATE TABLE `article_category` (
  `id` int(11) NOT NULL COMMENT 'Id (clef principale) categorie',
  `name` varchar(256) NOT NULL COMMENT 'Nom de la categorie'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Table des catégories d''article du site';

--
-- Contenu de la table `article_category`
--

INSERT INTO `article_category` (`id`, `name`) VALUES
(1, 'Musique'),
(2, 'Sport'),
(3, 'Sciences');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL COMMENT 'Id (clef principale) utilisateur',
  `username` varchar(128) NOT NULL COMMENT 'Username',
  `password_hash` varchar(128) NOT NULL COMMENT 'Hash du mot de passe',
  `firstname` varchar(128) NOT NULL COMMENT 'Prénom',
  `lastname` varchar(256) NOT NULL COMMENT 'Nom',
  `email` varchar(128) NOT NULL COMMENT 'Adresse courriel utilisateur'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Table des utilisateurs du site';

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `username`, `password_hash`, `firstname`, `lastname`, `email`) VALUES
(191, 'gp', '$2y$10$d0CFY8LxQdL3HNOR0eqzuuaGdcz3POKVlG.kzoCuIG63jb1vCNeAS', 'Gilles', 'Pénissard', 'gilles.penissard@isi-mtl.com'),
(192, 'pinocchio', '$2y$10$YIZxh/qrkVT/WG6Aa.j7/e/u1YH/foenqnFddi5of.x..j10Pbsua', 'Pinocchio', 'La marionetta', 'pinocchio.marionetta@isi-mtl.com'),
(193, 'jiminy', '$2y$10$g775jThAE0Axo/hZqcoSbOoZ6xUdyE70AErOyl.pGZD2IXn5/dq6y', 'Jiminy', 'Cricket', 'jiminy.cricket@isi-mtl.com');

-- --------------------------------------------------------

--
-- Structure de la table `user_cnx`
--

CREATE TABLE `user_cnx` (
  `cnx_id` int(11) NOT NULL COMMENT 'Id de connexion',
  `user_id` int(11) NOT NULL COMMENT 'Id de l''utilisateur',
  `session_id` varchar(126) NOT NULL COMMENT 'l''id de session de l''utilisateur',
  `date_in` datetime NOT NULL COMMENT 'Date de la dernière connexion',
  `date_last_access` datetime NOT NULL COMMENT 'Date dernier accès au site',
  `date_out` datetime DEFAULT NULL COMMENT AS `Date de la dernière déconnexion`
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `user_cnx`
--

INSERT INTO `user_cnx` (`cnx_id`, `user_id`, `session_id`, `date_in`, `date_last_access`, `date_out`) VALUES
(1, 191, '_gp_', '2016-05-15 19:51:26', '2016-05-15 19:51:26', '2016-05-15 19:51:26'),
(2, 193, '_jiminy_', '2016-05-15 19:51:26', '2016-05-15 19:51:26', NULL),
(3, 191, '_gp_', '2016-05-15 19:51:26', '2016-05-15 19:51:26', NULL);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Index pour la table `article_category`
--
ALTER TABLE `article_category`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Index pour la table `user_cnx`
--
ALTER TABLE `user_cnx`
  ADD PRIMARY KEY (`cnx_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Id (clef principale) de l''article', AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT pour la table `article_category`
--
ALTER TABLE `article_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Id (clef principale) categorie', AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Id (clef principale) utilisateur', AUTO_INCREMENT=194;
--
-- AUTO_INCREMENT pour la table `user_cnx`
--
ALTER TABLE `user_cnx`
  MODIFY `cnx_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Id de connexion', AUTO_INCREMENT=4;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `article_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `article_category` (`id`);

--
-- Contraintes pour la table `user_cnx`
--
ALTER TABLE `user_cnx`
  ADD CONSTRAINT `user_cnx_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
