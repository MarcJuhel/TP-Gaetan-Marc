-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mer 03 Août 2016 à 20:46
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `p62_dbkitdem_lite`
--

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL COMMENT 'Id (clef principale) de l''article',
  `name` varchar(256) NOT NULL COMMENT 'Nom de l''article ',
  `category_id` int(11) DEFAULT NULL COMMENT AS `Catégorie à laquelle appartient l'article`,
  `description` varchar(1024) NOT NULL COMMENT 'Description de l''article',
  `picture` varchar(128) NOT NULL COMMENT 'Photo de l''article',
  `price` decimal(8,2) DEFAULT NULL COMMENT AS `Prix de l'article`,
  `is_online` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Indique si l''article est affiché ou pas'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Table des articles (forfaits, livres, metériel, etc...) du site';

--
-- Contenu de la table `article`
--

INSERT INTO `article` (`id`, `name`, `category_id`, `description`, `picture`, `price`, `is_online`) VALUES
(1, 'Céline au Centre Bell', 1, 'Bla bla bla en HTML', 'photo_article.jpg', '159.99', 1),
(2, 'Grand prix cycliste de Montréal', 2, 'Bla bla bla en HTML', 'photo_article.jpg', '98.90', 1),
(3, 'Lady Gaga au centre Bell', 1, 'Bla bla bla en HTML', 'photo_article.jpg', '134.00', 1),
(4, 'Formule 1 au Parc Jean Drapeau', 2, 'Bla bla bla en HTML', 'photo_article.jpg', '225.00', 1),
(5, 'Concert des Fifty Six', 1, 'Bla bla bla en HTML', 'photo_article.jpg', '112.00', 1);

-- --------------------------------------------------------

--
-- Structure de la table `article_category`
--

CREATE TABLE `article_category` (
  `id` int(11) NOT NULL COMMENT 'Id (clef principale) catégorie',
  `name` varchar(256) NOT NULL COMMENT 'Nom de la catégorie'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Table des catégories des articles du site';

--
-- Contenu de la table `article_category`
--

INSERT INTO `article_category` (`id`, `name`) VALUES
(1, 'Musique'),
(2, 'Sport'),
(3, 'Sciences');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL COMMENT 'Id (clef principale) utilisateur',
  `username` varchar(128) NOT NULL COMMENT 'Username',
  `password_hash` varchar(128) NOT NULL COMMENT 'Hash du mot de passe',
  `firstname` varchar(128) NOT NULL COMMENT 'Prénom',
  `lastname` varchar(256) NOT NULL COMMENT 'Nom',
  `email` varchar(128) NOT NULL COMMENT 'Adresse courriel utilisateur'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Table des utilisateurs du site';

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `username`, `password_hash`, `firstname`, `lastname`, `email`) VALUES
(188, 'gp', '$2y$10$qgHMNfbLXi0C90dMVratou9TMQ/zf9Le/mIkVQF9856lYlZvVHKg2', 'Gilles', 'Pénissard', 'gilles.penissard@isi-mtl.com'),
(189, 'pinocchio', '$2y$10$HMedEASO9EmJAYK0MayBzud05y.WacMwvtilOCivigCMFlVkGSHS2', 'Pinocchio', 'La marionetta', 'pinocchio.marionetta@isi-mtl.com'),
(190, 'jiminy', '$2y$10$bmywgS/L.oHNJnZnI4Xc9e82yzLkQjQoFXthoBatwVBRhRQik7scW', 'Jiminy', 'Cricket', 'jiminy.cricket@isi-mtl.com');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Index pour la table `article_category`
--
ALTER TABLE `article_category`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Id (clef principale) de l''article', AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `article_category`
--
ALTER TABLE `article_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Id (clef principale) catégorie', AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Id (clef principale) utilisateur', AUTO_INCREMENT=191;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `article_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `article_category` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
